/**********************
ZombieDice.c
By: Ryan Scheppler and finished by :
Last Edited: 9/27/17
Brief: A dice game meant for up to 8 people, player with the most after one gets 13 or more brains wins
gcc -Wall -Wextra -ansi -pedantic -O -o ZombieDice ZombieDice.c
**********************/
/*printf, scanf*/
#include <stdio.h>
/*rand, srand*/
#include <stdlib.h>
/*time*/
#include <time.h>

#define MAXPLAYERS 8
/*declare functions*/
/*A full player's turn returns how many brains they earned*/
int PlayerTurn();
/*shuffle all brains back into bag not the shots return total dice*/
int RefreshDice(int dicePool[], int shotArray[]);
/*Call to pause for an enter*/
void WaitForEnter();
/*Clears the screen*/
void ClearScreen();

int main(void)
{
	int NumOPlayers = -1;
	int playerScores[MAXPLAYERS] = {0};
	int currentPlayer = 0;
    int i; 
	int winner = -1;
	int tie=1; /*This is a boolean variable for a tie*/

	
	srand(time(NULL));
	
	while (NumOPlayers < 0 || NumOPlayers > 8)
	{
		ClearScreen();
		printf("Input Number of Players! (Max %d): ", MAXPLAYERS);
		scanf(" %i", &NumOPlayers);
		WaitForEnter();
	}
	/*game loop, will break when and condition is met*/
	while(1)
	{
		ClearScreen();
		printf("Player %i's Turn", currentPlayer + 1);
		WaitForEnter();
		playerScores[currentPlayer] += PlayerTurn();
		/*Prints all player's scores after every turn*/
		for(i = 0; i < NumOPlayers; i++)
		{
			printf("Player %i's Score: %i \n", i + 1, playerScores[i]);
		}
		WaitForEnter();
		ClearScreen();
		if(currentPlayer != NumOPlayers -1)
			currentPlayer ++;
		else
			currentPlayer = 0;
		
		/*end condition*/
		if(playerScores[currentPlayer] >= 13)
		{
			break;
		}
	}
	/*figure out who won here also print scores*/
		for(i = 0; i < NumOPlayers; i++)
		{
			printf("Player %i's Score: %i \n", i + 1, playerScores[i]);
		    if(playerScores[winner] < playerScores[i])
			{	
		        winner = i;
			}
		}
		/*Checks if multiple players have ther same score at the end of the game and creates another round if so*/
		/*Screen intentionally does not get cleared during end game*/
		while (tie == 1) 
		{
            for(i = 0; i < NumOPlayers; i++)
		    {		
	            if ((playerScores[i] == playerScores[winner]) &&  (i != winner))
			    {
				   printf("\nThis is a tie!.\n");
				   printf("\nPlayer %i's Turn", i + 1);
				   WaitForEnter();
		   		   playerScores[i] += PlayerTurn();
				   printf("\nPlayer %i's Turn", winner + 1);
				   WaitForEnter();
				   playerScores[winner] += PlayerTurn();
				   if (playerScores[i] > playerScores[winner])
				   {
					   winner = i;
				   }
				   tie=1;
				   break;
		        }
				else
				{
					tie = 0;
				}
			}
	    }
	printf("\nPlayer %i is the winner!\n", winner +1);
	return 0;
}
/*A full player's turn returns how many brains they earned*/
int PlayerTurn()
{
	/*turn set up*/
	int dicePool[3] = {6, 4, 3};
	int shotArray[3] = {-1, -1, -1}; /*Can get rid of if wanted*/
	int current3Dice[3] = {-1, -1, -1};
	
	char input = 'y';
	int brains = 0;
	int shots = 0;
	
	int totalDice;
	int i, j;
	
	totalDice = RefreshDice(dicePool, shotArray);
	
	/*For runners set all other types to negative one and only reroll the dice if current3Dice = -1*/
	
	while(input != 'n')
	{		
		/*Randomly chooses which color dice will be rolled*/
		for(j = 0; j < 3; j++)
		{
			if(current3Dice[j] == -1)
			{
				int dietype = rand()%totalDice;
				if((dietype-= dicePool[0]) <=0)
				{
					printf("You drew a green die.\n");
					current3Dice[j] = 0;
					dicePool[0]-=1;
				}		
				else if((dietype-= dicePool[1]) <=0)
				{
					printf("You drew a yellow die.\n");
					current3Dice[j] = 1;
					dicePool[1]-=1;				
				}
				else if((dietype-= dicePool[2]) <=0)
				{
					printf("You drew a red die.\n");
					current3Dice[j] = 2;
					dicePool[2]-=1;
				}
				totalDice -= 1;
			}
			    
		}
		/*Randomly selects which side the dice lands on*/
		for(i = 0; i < 3; i++)
		{
			int side = rand()%6;
			if(current3Dice[i] == 0)
			{
				printf("Green die = ");
				if(side == 3 || side == 4 || side == 5)
				{
					printf("Brains +1\n");
					brains += 1;
					current3Dice[i] = -1;
				}
				if(side == 1 || side == 2)
				{
					printf("Runners +1\n");
				}
				if(side == 0)
				{
					printf("Shots +1\n");
					shots += 1;
					current3Dice[i] = -1;
				}
			}
			else if(current3Dice[i] == 1)
			{
				printf("Yellow die = ");
				if(side == 4 || side == 5)
				{
					printf("Brains +1\n");
					brains += 1;
					current3Dice[i] = -1;
				}
				if(side == 2 || side == 3)
				{
					printf("Runners +1\n");
				}
				if(side == 0 || side == 1)
				{
					printf("Shots +1\n");
					shots += 1;
					current3Dice[i] = -1;
				}
			}
			else if(current3Dice[i] == 2)
			{
				printf("Red die = ");
				if(side == 5)
				{
					printf("Brains +1\n");
					brains += 1;
					current3Dice[i] = -1;
				}
				if(side == 3 || side == 4)
				{
					printf("Runners +1\n");
				}
				if(side == 0 || side == 1 || side == 2)
				{
					printf("Shots +1\n");
					shots += 1;
					current3Dice[i] = -1;
				}
			}
		}
		/*player loses all brains collected in their turn if they get 3 shots or more*/
		if(shots >= 3)
		{
			break;
		}
		/*Refreshes the dicepool if the player uses up all of the 13 avaliable dice*/
		if(totalDice <= 3)
		{
			totalDice = RefreshDice(dicePool, shotArray);
		}
		printf("\nTotal Brains: %i\n", brains);
		printf("Total Shots: %i\n", shots);
		printf("Total Dice: %i\n", totalDice);
		do
		{
			printf("Would you like to roll again?\n\n");
			scanf("%c", &input);
			WaitForEnter();
		} while(input != 'y' && input != 'n');
		
		if(input == 'n')
		{
			break;
		}
	}
	/*player loses all brains collected in their turn if they get 3 shots or more*/
	if(shots >= 3)
	{
		brains = 0;
		printf("\nYou Got shot too many times and lost all of your brains!\n");
		printf("Brains: %i\n", brains);
		WaitForEnter();
	}
	
	return brains;
	
}
/*shuffle all brains back into bag not the shots return total dice*/
int RefreshDice(int dicePool[], int shotArray[])
{
	
	int i, total;
	/*green dice total*/
	dicePool[0] = 6;
	/*yellow dice total*/
	dicePool[1] = 4;
	/*red dice total*/
	dicePool[2] = 3;
	/*all dice*/
	total = dicePool[0] + dicePool[1] + dicePool[2];
	printf("\n\"Refreshing Dice Pool\"\n");
	/*remove dice currently saved as a shot*/
	for(i = 0; i <3 ; i++)
	{
		if(shotArray[i] > -1)
		{
			dicePool[shotArray[i]] -= 1;
			total--;
		}
	}
	return total;
}
/*Call to pause for an enter, also needs to be used after scanf if used to remove any excess characters and newlines*/
void WaitForEnter()
{
	char input = 'a';
	while(input != '\n')
	{
		input = getchar();
	}
}

/*Clears the screen*/
void ClearScreen()
{
	system("clear");
}