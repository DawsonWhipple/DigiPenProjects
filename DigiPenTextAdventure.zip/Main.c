/*
Name: Main.c
By: David Cohen
Date: 1/26/18
Brief: Basic framework that handles getting input and calling room functions
gcc -Wall -Wextra -ansi -pedantic -O -o main Main.c Parser.c Utils.c map.c
*/

#include "Includes.h"
#include "Parser.h"
#include "map.h"
#include <time.h>

#define INVALIDCMDNUM 4
char *INVALIDCMDMSG[] = {"You’re not very good at this.", "Sorry, we only wrote the parser in english. As such, it does not understand spanish.", "Invalid command.", "Try typing [help] to get help. Clearly you need it."};

int main(void)
{
    /*int i;*/
	char input[256];
	int bufSize = 256;
	InputData data;
	int commandID = -1;
	int currentRoom = DETECTIVEONE;
	int nextRoom = -1;
	
	srand(time(NULL));
	
	printf("  _______   _                   _        _____  \n |__   __| (_)                 | |      |  __ \\ \n    | |_ __ _ _ __  _ __  _ __ | | ___  | |  | |\n    | | '__| | '_ \\| '_ \\| '_ \\| ");
	printf("|/ _ \\ | |  | |\n    | | |  | | |_) | |_) | |_) | |  __/ | |__| |\n    |_|_|  |_| .__/| .__/| .__/|_|\\___| |_____/ \n             | |   | |   | |                    \n             |_|   |_|   |_|");
	
	printf("\n\n\n   An Uncandy Robbery\n------------------------\n\n");
	
	printf("Welcome, you own a freelance detective business in the town of Grand Lake. If you find yourself stuck try typing [help]. If you want to quit the game, type [quit].\n");
    
    printf("\nYou’re sitting alone in your office. You can see a door straight north from you and a window to the east. The phone rings. It’s a frantic call from an anonymous caller about a robbery at the town’s local gas station. It sounds serious. You hang up the phone. you better get out there as soon as you can.\n");
    
    printf("\n%s\n", ROOM_KEYS[currentRoom]);
	
    do {
		data = getInput(input, bufSize);
        
        printf("\n");
		
		if (data.commandsCount > 0)
			commandID = data.commands[0];
		else
			commandID = -1;
		
		nextRoom = -1;
		
		if (commandID == HELP)
		{
			printf("[quit] - Quit the game\n");
			printf("[north] - Move North\n");
			printf("[east] - Move East\n");
			printf("[south] - Move South\n");
			printf("[west] - Move West\n");
			printf("[look] - Look\n");
			printf("[take] - Take an item\n");
			printf("[use] - Use an item\n");
			printf("[talk] - Talk to an NPC\n\n");
			printf("Note:\n");
			printf("Some commands may require a subject. Specifically, [look], [take], [use], and [talk].\n");
			nextRoom = -2;
		}
        else if (commandID == QUIT)
        {
            nextRoom = -2;
        }
		else
		{
			switch (currentRoom)
			{
				case DETECTIVEONE:
					nextRoom = detectiveOne(data);
					break;
				case DETECTIVETWO:
					nextRoom = detectivetwo(data);
					break;
				case TOWNSQUARE:
					nextRoom = townsquare(data);
					break;
				case GASSTATION:
					nextRoom = gasstation(data);
					break;
				case GROCERY:
					nextRoom = grocery(data);
					break;
				case BEHINDGROCERY:
					nextRoom = behindGrocery(data);
					break;
				case OUTSKIRTS:
					nextRoom = outskirts(data);
					break;
				case DEEPWOODS:
					nextRoom = deepwoods(data);
					break;
				case POST:
					nextRoom = post(data);
					break;
				case BASEMENT:
					nextRoom = basement(data);
					break;
				case LOCKED:
					nextRoom = locked(data);
					break;
				case WINROOM:
					nextRoom = winroom(data);
					break;
				case LAKE:
					nextRoom = lake(data);
					break;
			}
		}
		
		if (nextRoom >= 0)
		{
			currentRoom = nextRoom;
			
			switch (currentRoom)
			{
				case DETECTIVEONE:
					printf("This is your base of operations. There’s nothing remarkable going on here right now other than that moldy grilled cheese you left in the corner. You should probably clean that up… But we’ve got places to be. You can see a door straight north from you and a window to the east.\n");
					break;
				case WINDOW:
					printf("You go up to the third story window and jump out. I guess you really didn’t want to solve that crime.\n");
					return 0;
				case DETECTIVETWO:
					printf("You’ve left your office and come downstairs to the front office of your building. The exit is to the north of you and the way back is south.\n");
					break;
				case TOWNSQUARE:
					printf("This is the Town Square. It is the center point of the entire town. You can get to everywhere from here. To the North is the Gas station that the robbery took place at. To the East is the Post Office. To the west is the Grocery store. To the South is the Town Outskirts, it can be dangerous out there but kids tend to go there to play.\n");
					break;
				case GASSTATION:
					printf("You walk into the Gas station and see a clerk working behind the counter. His name tag says Dan. Outside you can see the Town Square to the South where you came from. To the West is the town’s local grocery store. To the North is a supposed ‘bottomless pit’. You never believed that it was truly bottomless, but there's no way to find out.\n");
					break;
				case BOTTOMLESS:
					printf("You reluctantly peer over the edge of the bottomless pit. Shockingly, you can’t see the bottom. You drop a coin down to see how far the fall is. After waiting for just a little more than a reasonably long time for something the size of a coin to fall down a hole, you conclude that it didn’t hit the bottom. As you’re looking over the edge you lean a little too far over and fall in. You continue falling for more than a reasonably long time one would expect a human falling down a hole to fall for.");
					printf(" It looks like you’re going to be falling for the rest of eternity. There’s no apparent way out of this predicament you’ve gotten yourself into.\n");
					return 0;
				case POST:
					printf("This is the Grand Lake Post Office. It seems like there’s always a mile long line that awkwardly wraps back on itself forcing you to stare into the eyes of the other miserable occupants of this place. There’s only one worker in the entire building. His name seems to be David. At Least that’s what his name tag says. To the north of you is an entrance to the basement of the post office. To the west is the Town Square.\n");
					break;
				case BASEMENT:
					printf("You step into a large, hollow basement. The air is musty and damp, and as your shoes scuff the ground, a scent reminiscent of sour milk fills the air. Trying as best you can to not breathe the foul odor that surrounds you, you can’t help but wonder what poor animal gave its life to produce such a stench. To the south is a staircase leading up to the post office. To the north is a rusty metal gate, protected by a hefty padlock of considerable size.");
					printf(" There’s no getting in there without a hefty key of considerable size.\n");
					break;
				case GROCERY:
					printf("This is the town’s local grocery store. Soccer moms can commonly be seen here conversing with each other while their kids run into each other with grocery carts. You see a cashier that doesn’t seem to be doing much. To the South is the back of the grocery store. To the North is the gas station. To the east is the Town Square. To the West is the famed Grand Lake. The lake the town is named after.\n");
					break;
				case BEHINDGROCERY:
                    if (!hasItem(JERKY))
                    {
                        printf("Behind the Grocery store there’s nothing but Industrial sized dumpsters overflowing with raccoons. You can see a trash can fire off in the distance that seems abandoned. There’s nothing else remarkable here except a half eaten bag of beef jerky. That could serve as a good snack for later but it looks somewhat repulsive. To the north is the front of the grocery store and to the east you can see the town outskirts.\n");
                    }
                    else
                    {
                        printf("Behind the Grocery store there’s nothing but Industrial sized dumpsters overflowing with raccoons. You can see a trash can fire off in the distance that seems abandoned. There’s nothing else remarkable here. To the north is the front of the grocery store and to the east you can see the town outskirts.\n");
                    }
					break;
				case OUTSKIRTS:
					printf("These are the town outskirts. Kids like to come here to rebel against their parents. It’s sad really. To the North is the town square. To the west you can see the back of the local town grocery store. To the South you can see the woods, it’s dangerous to go alone out there.\n");
					break;
				case WOODS:
					if (!hasItem(JERKY))
					{
						if (!hasItem(RACCOON))
						{
							printf("You step into the woods alone. As you’re wandering aimlessly you lose your way and start running in circles. You hear a noise in the distance. Suddenly, you see a bear running directly at you. You’re paralyzed with fear and can’t move a muscle. The bear gets to you before you can get away. Looks like that’s the end of your detective days.\n");
							return 0;
						}
						printf("You step into the woods alone. As you’re wandering aimlessly you lose your way and start running in circles. You hear a noise in the distance. Suddenly, you see a bear running directly at you. You’re trembling so hard that the raccoon you were carrying falls out of your pocket. The bear stops running towards you and focuses its attention on the ‘coon. You use this time to sneak off deeper into the woods.\n");
					}
					else
					{
						if (!hasItem(RACCOON))
						{
							printf("You step into the woods alone. As you’re wandering aimlessly you lose your way and start running in circles. You hear a noise in the distance. Suddenly, you see a bear running directly at you. You’re trembling so hard that the beef jerky you were carrying falls out of your pocket. The bear stops running towards you and focuses its attention on the beef jerky. It is completely enveloped by this magical mystery meat. You use this time to sneak off deeper into the woods.\n");
						}
						else
						{
							printf("You step into the woods alone. As you’re wandering aimlessly you lose your way and start running in circles. You hear a noise in the distance. Suddenly, you see a bear running directly at you. You’re trembling so hard that the raccoon you were carrying falls out of your pocket with a firm grasp on the beef jerky you had. The bear stops running towards you and focuses its attention on the ‘coon. The raccoon runs off towards the grocery store and the bear chases after.");
							printf(" You use this time to sneak off deeper into the woods.\n");
						}
					}
					
                    setItem(JERKY, FALSE);
					currentRoom = DEEPWOODS;
					/* no break because you skip into DEEPWOODS without user input */
				case DEEPWOODS:
                    if (!hasItem(KEY))
                    {
                        printf("Now even deeper into the woods you think you’ll never find your way back. But then, as if you had been hit in the back of the head by the extended arm of god. You see a ray of light shining through the trees directed straight towards a stump with a hefty key of considerable size on it. As you approach the key you can see your reflection glimmering off the beautiful golden handle that it possesses. This could prove useful in the future. Off to the east you can see a glimpse of the town square.\n");
                    }
                    else
                    {
                        printf("There’s a stump with nothing on it. To the east is the way back to the town square.\n");
                    }
					break;
				case LOCKED:
					printf("Having to stoop down so as not to hit your head on the stone ceiling, you enter a cramped, dimly lit chamber. The entire room is at a slight angle, causing small pools of muddy water to form in the north corners. You consider visiting a chiropractor after this case to treat your sore neck you must keep down under the low ceiling. You see two possible doors to go through. One to the North and another to the West.\n");
					break;
				case DEATHROOM:
					printf("You entered the room to the North. The door slams behind you and you can’t get it open again. You hear a distant laughter and then the cramped room starts to fill with water. You gasp for breath as you get engulfed by the water. This seems to create more questions than it answers. It looks like there were more important things to be investigating than a missing candy bar.\n");
					return 0;
				case WINROOM:
					printf("You enter the room to the west. You find a note on the floor that has a map with directions to somewhere in the middle of the forest. The door behind you is stuck closed but you see sunlight to the north of you.\n");
					break;
				case HIDEOUT:
					printf("You slowly make your way through thick wood and brush, eventually stumbling into a small clearing. There are several large boulders strewn about the green grass, and upon further examination, one reveals a crack just large enough to accomodate a person. Making your way deeper into the cave, you see the light of a torch from around the corner.");
					printf(" You peer around the corner and see the culprit passed out on the floor with his familiar bucketed head and pantless legs. There’s a name tag pinned into his bare chest. It says Sean. You have him reprimanded and get the candy bar back to the gas station. They let you keep it as a reward! You hastily rip into the chocolate bar and go for a bite. But as your head is jerking towards the candy bar you notice it’s full of peanuts. You’re allergic to peanuts…\n");
                    printf("\nCongratulations, you win!\n");
					return 0;
				case LAKE:
                    if (!hasItem(FISH))
                    {
                        printf("This is Grand Lake. There’s a brightly colored fish flailing about on the shore. You still have fond memories of those times back in high school. Back when she was still here. Before she ever met brad. Those were the good ol’ days. It’s a shame really… To the east is the way back to the grocery store.\n");
                    }
                    else
                    {
                        printf("This is Grand Lake. You still have fond memories of those times back in high school. Back when she was still here. Before she ever met brad. Those were the good ol’ days. It’s a shame really… To the east is the way back to the grocery store.\n");
                    }
					break;
			}
		}
		else if (nextRoom == -1)
		{
			printf("%s\n", INVALIDCMDMSG[rand() % INVALIDCMDNUM]);
		}
        
        printf("\n%s\n", ROOM_KEYS[currentRoom]);
	} while (commandID != QUIT);
	
	return 0;
}