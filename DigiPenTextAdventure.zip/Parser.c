/*
Name: Parser.c
By: David Cohen
Date: 1/26/18
Brief: Contains the main parser functionality
*/

/* Includes */
#include "Includes.h"
#include "Parser.h"
#include "Utils.h"
#include <string.h>

/* Inventory is an integer used as a bitfield (int = 4 bytes = 32 bits = 32 slots) */
unsigned int inventory = 0;

const char *ITEM_KEYS[ITEM_COUNT] = {"key", "jerky", "cheese", "raccoon", "fish"};

const char *COMMAND_KEYS[COMMAND_COUNT] = {"quit", "help", "north", "east", "south", "west", "look", "take", "use", "talk"};

const char *NPC_KEYS[NPC_COUNT] = {"dan", "david", "dawson"};

/* Checks the inventory bitfield for if the user has the item at (index) */
bool hasItem(int index)
{
    /* Invalid index */
	if (index < 0 || index > 31) return 0;
	
    /* Get the bit at (index) */
    /* Bitwise shift 0x1 to the left by (index) bits */
    /* and use a bitwise AND operator to check if only the selected bit is 1 */
	return (inventory & (1 << index)) != 0;
}

/* Sets whether the user has the item at (index) in the inventory bitfield */
void setItem(int index, bool enabled)
{
    /* Invalid index */
	if (index < 0 || index > 31) return;
	
	/* Set the bit at (index) to 0 */
	/* Bitwise shift 0x1 to the left by (index) bits */
	/* then use a bitwise NOT operator on it */
	/* and use a bitwise AND operator to force the (index) bit to 0 */
	inventory &= ~(1 << index);
	
	/* Set the bit at (index) to 1 */
	/* Bitwise shift 0x1 to the left by (index) bits */
	/* and use a bitwise OR operator to set just the (index) bit to 1 */
	if (enabled) inventory |= 1 << index;
}

/* Gets input from the user and returns all found info in the form of a neat struct */
InputData getInput(char *input, int bufSize)
{
    InputData out;
	int i, found, currentPhrase;
	char words[16][256] = {0};
    int commands[16] = {0};
    int commandsCount = 0;
    int items[16] = {0};
    int itemsCount = 0;
	int npcs[16] = {0};
	int npcsCount = 0;
	
    /* Clamp the buffer size to a maximum of 256 */
	if (bufSize > 256) bufSize = 256;
	
	printf("\n> ");
	fgets(input, bufSize, stdin);
	
    /* Clean up the input, make it lower-case, removal illegal characters, and remove extra whitespice */
	sanitize(input);
	
    /* Split up the input into an array of words found between spaces */
	splitSpaces(input, words, &found);
    
    /* Copy the found words to the output struct */
    copyArray((unsigned char*) words, (unsigned char*) out.words, sizeof(words));
    out.wordsCount = found;
    
    /* Reset i for use as the current word index */
	i = 0;
    
    /* Find all instances of commands */
	while ((currentPhrase = findNextPhrase(words, COMMAND_KEYS, COMMAND_COUNT, found, &i)) != -1)
	{
        commands[commandsCount++] = currentPhrase;
	}
    
    /* Copy the found commands to the output struct */
    copyArray((unsigned char*) commands, (unsigned char*) out.commands, sizeof(commands));
    out.commandsCount = commandsCount;
    
    /* Reset i for use as the current word index */
	i = 0;
	
    /* Find all instances of items */
	while ((currentPhrase = findNextPhrase(words, ITEM_KEYS, ITEM_COUNT, found, &i)) != -1)
	{
        items[itemsCount++] = currentPhrase;
	}
    
    /* Copy the found items to the output struct */
    copyArray((unsigned char*) items, (unsigned char*) out.items, sizeof(items));
    out.itemsCount = itemsCount;
	
	/* Reset i for use as the current word index */
	i = 0;
	
    /* Find all instances of NPCs */
	while ((currentPhrase = findNextPhrase(words, NPC_KEYS, NPC_COUNT, found, &i)) != -1)
	{
        npcs[npcsCount++] = currentPhrase;
	}
    
    /* Copy the found NPCs to the output struct */
    copyArray((unsigned char*) npcs, (unsigned char*) out.npcs, sizeof(npcs));
    out.npcsCount = npcsCount;
    
    return out;
}