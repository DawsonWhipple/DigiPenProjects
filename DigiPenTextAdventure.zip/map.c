/*****************
Filename: 	map.c
Author: 	Dawson Whipple, David Cohen, Daniel Walther
Date: 		1/26/18
Brief:		This code stores where the player currently is on the map and determines how to properly move bewteen locations
*****************/
#include <ctype.h> /* tolower */
#include <stdio.h> /* fgets */

#include "Includes.h"
#include "map.h"
#include "Parser.h"
#include "Utils.h"

const char *ROOM_KEYS[ROOMNUM] = {"Detective's Office", "Window", "Front Room of Detective's Office", "Town Square", "Gas Station", "Bottomless Pit", "Grocery Store", "Behind Grocery Store", "Town Outskirts", "Woods", "Deep Woods", "Post Office", "Post Office Basement", "Locked Door", "Death Room", "Win Room", "Robber's Hideout", "Grand Lake"};
const char *RANDOMTALK[RANDTALKNUM] = {"You really should stop talking to yourself...","There's nobody here...", "You are alone.", "There's nobody to talk to here except yourself.", "There is nobody else here...", "You don't like the sound of your voice.","As the words just finish leaving your mouth you hear them echo off of your surroundings. There’s no one here. You’re all alone. Distant memories of your father’s voice bounce around in your mind. You can hear him telling you that you’ll never succeed as a detective. That you’ll never be as good as your brother. If only you went to to his funeral to see him one last time… better get going.","No one responds, it’s almost like you can still hear her voice even when there’s nothing there."};

void randomTalk()
{
	srand(time(NULL));
	
	puts(RANDOMTALK[rand() % RANDTALKNUM]);
}

int detectiveOne(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case NORTH:
			return DETECTIVETWO;
			
		case EAST:
			return WINDOW;
			
		
		case LOOK:
            if (isWordInArray(data.words, data.wordsCount, "window"))
            {
                printf("It’s a window. You’re too far away to be able to see out of it.\n");
                return -2;
            }
			printf("This is your base of operations. There’s nothing remarkable going on here right now other than that moldy grilled cheese you left in the corner. You should probably clean that up… But we’ve got places to be. You can see a door straight north from you and a window to the east.\n");
			return -2;
			
		case TAKE:
			if (!hasItem(CHEESE) && data.itemsCount > 0 && data.items[0] == CHEESE)
			{
				printf("You probably shouldn’t touch that, I think I saw it move earlier. But if you insist.\n");
				return -2;
			}
			return -1;
			
		case TALK:
			randomTalk();
			return -2;
			
	}
	
	return -1;
}

int detectivetwo(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case NORTH:
			return TOWNSQUARE;
			
		case SOUTH:
			return DETECTIVEONE;
			
			
		case LOOK:
			printf("You are in the front office of your building. The exit is to the north of you and the way back is south.\n");
			return -2;
			
		case TALK:
			randomTalk();
			return -2;
	}
	
	return -1;
}

int townsquare(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case NORTH:
			return GASSTATION;
			
		case EAST:
			return POST;
			
		case SOUTH:
			return OUTSKIRTS;
			
		case WEST:
			return GROCERY;
			
			
		case LOOK:
			printf("This is the Town Square. It is the center point of the entire town. You can get to everywhere from here. To the North is the Gas station that the robbery took place at. To the East is the Post Office. To the west is the Grocery store. To the South is the Town Outskirts, it can be dangerous out there but kids tend to go there to play.\n");
			return -2;
			
		case TALK:
			randomTalk();
			return -2;
	}
	
	return -1;
}

int gasstation(InputData data)
{
	int commandID = -1;
    bool npcAlias = isWordInArray(data.words, data.wordsCount, "clerk");
    if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case NORTH:
			return BOTTOMLESS;
			
		case SOUTH:
			return TOWNSQUARE;
			
		case WEST:
			return GROCERY;
			
			
		case LOOK:
			if (npcAlias || data.npcsCount > 0)
			{
				if (npcAlias || data.npcs[0] == DAN)
				{
					printf("You take a good long look at the store clerk. He’s got a name tag that says Dan on it. Hm. He’s wearing beaten up skate shoes, jeans that are just a little bit too blue and a baggy white collared shirt that he clearly doesn’t ");
					printf("want to be wearing but he has no choice. On top of that he’s got a vertical striped brightly colored apron with the gas station logo on it and a similar looking hat. His hair is long and sweeps in front of his eyes so he doesn’t have to look at you. He clearly doesn’t want to be here.\n");
					return -2;
				}
				return -1;
			}
            if (isWordInArray(data.words, data.wordsCount, "pit"))
            {
                printf("You need to get closer to be able to see down it.\n");
                return -2;
            }
			printf("You are in a gas station. You see a clerk behind the counter whose name tag says Dan. Outside you can see the Town Square to the South where you came from. To the West is the town’s local grocery store. To the North is a supposed ‘bottomless pit’. You never believed that it was truly bottomless, but there's no way to find out.\n");
			return -2;
			
		case TALK:
			if (npcAlias || data.npcsCount > 0)
			{
				if (npcAlias || data.npcs[0] == DAN)
				{
					printf("You ask the clerk about the robbery. He says,\n\n");
					printf("‘some guy came in wielding nothing but a wooden spoon. He had a bucket on his head and his pants were down to his ankles. He was flailing about so sporadically that I wasn’t able to stop him. All he ended up stealing was a candy bar, but the experience was so traumatic I needed to report it. There was one other person in the store at the time, I saw him go over to the Post Office. He had a name tag that said David on it. You might want to check there, I’ve got nothing more to tell.’\n\n");
					printf("Better get over to that Post office...\n");
					return -2;
				}
                return -1;
			}
            return -1;
	}
	
	return -1;
}

int grocery(InputData data)
{
	int commandID = -1;
    bool npcAlias = isWordInArray(data.words, data.wordsCount, "cashier");
	if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case NORTH:
			return GASSTATION;
			
		case EAST:
			return TOWNSQUARE;
			
		case SOUTH:
			return BEHINDGROCERY;
		case WEST:
			return LAKE;
			
		case LOOK:
			if (npcAlias || data.npcsCount > 0)
            {
                if (npcAlias || data.npcs[0] == DAWSON)
                {
                    printf("The cashier is a normal looking guy. His name tag says Dawson and his hair is just a little bit too greasy for your liking. He’s wearing the mandatory outfit that the local town grocery store requires him to wear. He’s got a forced smile on his face, and is blankly staring off into space.\n");
                    return -2;
                }
                return -1;
            }
            printf("This is the town’s local grocery store. Soccer moms can commonly be seen here conversing with each other while their kids run into each other with grocery carts. You see a cashier that doesn’t seem to be doing much. To the South is the back of the grocery store. To the North is the gas station. To the east is the Town Square. To the West is the famed Grand Lake. The lake the town is named after.\n");
            return -2;
			
		case TALK:
			if (npcAlias || data.npcsCount > 0)
			{
				if (npcAlias || data.npcs[0] == DAWSON)
				{
					printf("You walk up to him. His name tag says Dawson. You ask him about any shady characters he’s seen around. He says he hasn’t seen any but they tend to hang out behind the grocery store. Could be worth a look.\n");
					return -2;
				}
                return -1;
			}
            return -1;
			
	}
	
	return -1;
}

int behindGrocery(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case NORTH:
			return GROCERY;
			
		case EAST:
			return OUTSKIRTS;
			
			
		case LOOK:
            if (data.itemsCount > 0)
            {
                if (data.items[0] == JERKY)
                {
                    printf("A bag of once delicious dried meat. It looks a little too old to be safely eaten. Better stay clear.\n");
                    return -2;
                }
				if (data.items[0] == RACCOON)
				{
					printf("Those glorified garbage cats are always breaking into dumpsters. It’s not a surprise seeing them here.\n");
					return -2;
				}
                return -1;
            }
            if (isWordInArray(data.words, data.wordsCount, "raccoon") || isWordInArray(data.words, data.wordsCount, "raccoons"))
            {
                printf("Those glorified garbage cats are always breaking into dumpsters. It’s not a surprise seeing them here.\n");
                return -2;
            }
			if (hasItem(RACCOON))
			{
				printf("Behind the Grocery store there’s nothing but Industrial sized dumpsters overflowing with raccoons. You can see a trash can fire off in the distance that seems abandoned. There’s nothing else remarkable here. To the north is the front of the grocery store and to the east you can see the town outskirts.\n");
			}
			else
			{
				printf("Behind the Grocery store there’s nothing but Industrial sized dumpsters overflowing with raccoons. You can see a trash can fire off in the distance that seems abandoned. There’s nothing else remarkable here except a half eaten bag of beef jerky. That could serve as a good snack for later but it looks somewhat repulsive. To the north is the front of the grocery store and to the east you can see the town outskirts.\n");
			}
			return -2;
			
		case TAKE:
			if (data.itemsCount > 0)
			{
				if (!hasItem(JERKY) && data.items[0] == JERKY)
				{
					setItem(JERKY, TRUE);
					printf("You pick up the jerky and put it in your pocket.\n");
					return -2;
				}
				if (data.items[0] == RACCOON)
				{
					setItem(RACCOON, TRUE);
					printf("You quite skillfully snatch a raccoon. You shove the captured ‘coon into your pocket and continue on your way.\n");
					return -2;
				}
                return -1;
			}
            return -1;
			
		case TALK:
			printf("Conversing with raccoons is generally undesirable.\n");
			return -2;
	}
	
	return -1;
}

int outskirts(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case NORTH:
			return TOWNSQUARE;
			
		case SOUTH:
			return WOODS;
			
		case WEST:
			return BEHINDGROCERY;
			
			
		case LOOK:
			printf("These are the town outskirts. Kids like to come here to rebel against their parents. It’s sad really. To the North is the town square. To the west you can see the back of the local town grocery store. To the South you can see the woods, it’s dangerous to go alone out there.\n");
			return -2;
			
		case TALK:
			randomTalk();
			return -2;
	}
	
	return -1;
}

int deepwoods(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
    switch(commandID)
    {
        case EAST:
            return TOWNSQUARE;
			
			
		case LOOK:
			if (data.itemsCount > 0)
			{
				if (data.items[0] == KEY)
				{
					printf("You look down at the key on your side. It’s the most glorious thing you’ve ever seen. It shines brightly of gold and you can see the reflection of children playing in the distance. You refrain from touching it as much as you can as to not get your grimy fingerprints all over the beautiful shine.\n");
					return -2;
				}
				return -1;
			}
			
			if (hasItem(KEY))
			{
				printf("There’s a stump with nothing on it. To the east is the way back to the town square.\n");
				return -2;
			}
			printf("You are deep in the woods. You see a ray of light shining through the trees directed straight towards a stump with a hefty key of considerable size on it. As you approach the key you can see your reflection glimmering off the beautiful golden handle that it possesses. This could prove useful in the future. Off to the east you can see a glimpse of the town square.\n");
			return -2;
			
		case TAKE:
			if (data.itemsCount > 0)
			{
				if (data.items[0] == KEY)
				{
					setItem(KEY, TRUE);
					printf("You grasp the key firmly in your hands. It seems to glow with an otherworldly energy you have never experienced before. Better not drop it.\n");
					return -2;
				}
                return -1;
			}
            return -1;
			
		case TALK:
			randomTalk();
			return -2;
    }
	
	return -1;
}

int post(InputData data)
{
	int commandID = -1;
    bool npcAlias = isWordInArray(data.words, data.wordsCount, "witness") || isWordInArray(data.words, data.wordsCount, "clerk") || isWordInArray(data.words, data.wordsCount, "worker");
	if (data.commandsCount > 0) commandID = data.commands[0];
    switch(commandID)
    {
        case NORTH:
            return BASEMENT;
            
        case WEST:
            return TOWNSQUARE;
            
			
		case LOOK:
			if (npcAlias || data.npcsCount > 0)
			{
				if (npcAlias || data.npcs[0] == DAVID)
				{
					printf("That’s David. You know David. Everybody knows David. He’s a radical dude.\n");
					return -2;
				}
			}
			printf("This is the Grand Lake Post Office. It seems like there’s always a mile long line that awkwardly wraps back on itself forcing you to stare into the eyes of the other miserable occupants of this place. There’s only one worker in the entire building. His name seems to be David. At Least that’s what his name tag says. To the east of you is an entrance to the basement of the post office. To the west is the Town Square.\n");
			return -2;
			
		case TALK:
			if (npcAlias || data.npcsCount > 0)
			{
				if (npcAlias || data.npcs[0] == DAVID)
				{
					printf("You try to go talk to David but he says you have to wait in line to get service. You go to the back of the line. After waiting for fifteen minutes and thirty seven seconds you’ve made it to the front of the line and are finally able to talk with the witness. He says he saw the robber run towards the grocery store. Seems pretty straight forward.\n");
					return -2;
				}
                return -1;
			}
            return -1;
    }
	
	return -1;
}

int basement(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
    switch(commandID)
    {
        case USE:
            if (data.itemsCount <= 0 || data.items[0] != KEY || !hasItem(KEY)) return -1;
        case NORTH:
            if (hasItem(KEY))
            {
                printf("You put the considerably sized key into the considerably sized lock and it makes a considerably loud clicking noise. The gate slowly creeps open and you continue forward.\n");
                return LOCKED;
            }
            else
            {
                printf("There’s no getting through this gate without a hefty key of considerable size.\n");
                return -2;
            }
            
        case SOUTH:
            return POST;
            
			
		case LOOK:
			if (isWordInArray(data.words, data.wordsCount, "gate"))
			{
				printf("There’s no getting through this gate without a hefty key of considerable size.\n");
				return -2;
			}
			printf("You are in a large, hollow basement. The air is musty and damp, and as your shoes scuff the ground, a scent reminiscent of sour milk fills the air. Trying as best you can to not breathe the foul odor that surrounds you, you can’t help but wonder what poor animal gave its life to produce such a stench. ");
			printf("To the south is a staircase leading up to the post office. To the north is a rusty metal gate, protected by a hefty padlock of considerable size. There’s no getting in there without a hefty key of considerable size.\n");
			return -2;
			
		case TALK:
			randomTalk();
			return -2;
    }
	
	return -1;
}

int locked(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
    switch(commandID)
    {
        case NORTH:
			return DEATHROOM;
            
        case WEST:
			return WINROOM;
			
			
		case LOOK:
			printf("You are in a cramped, dimly lit chamber. The entire room is at a slight angle, causing small pools of muddy water to form in the north corners. You consider visiting a chiropractor after this case to treat your sore neck you must keep down under the low ceiling. You see two possible doors to go through. One to the North and another to the West.\n");
			return -2;
			
		case TALK:
			randomTalk();
			return -2;
    }
	
	return -1;
}

int winroom(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
    switch(commandID)
    {
        case NORTH:
            return HIDEOUT;
            
			
		case LOOK:
			printf("You enter the room to the west. You find a note on the floor that has a map with directions to somewhere in the middle of the forest. The door behind you is stuck closed but you see sunlight to the north of you.\n");
			return -2;
			
		case TALK:
			randomTalk();
			return -2;
    }
	
	return -1;
}

int lake(InputData data)
{
	int commandID = -1;
	if (data.commandsCount > 0) commandID = data.commands[0];
	switch(commandID)
	{
		case EAST:
			return GROCERY;
			
		case LOOK:
            if (!hasItem(FISH))
            {
                printf("This is Grand Lake. There’s a brightly colored fish flailing about on the shore. You still have fond memories of those times back in high school. Back when she was still here. Before she ever met brad. Those were the good ol’ days. It’s a shame really… To the east is the way back to the grocery store.\n");
            }
            else
            {
                printf("This is Grand Lake. You still have fond memories of those times back in high school. Back when she was still here. Before she ever met brad. Those were the good ol’ days. It’s a shame really… To the east is the way back to the grocery store.\n");
            }
			return -2;
			
		case TAKE:
			if (!hasItem(FISH) && data.itemsCount > 0)
			{
				if (data.items[0] == FISH)
				{
					setItem(FISH, TRUE);
					printf("You take the fish. It’s a red herring. You can’t do anything with this fish. Genuinely. This was added for no other reason then to pad out the game. Congratulations. You’ve accomplished nothing.\n");
					return -2;
				}
				return -1;
			}
			return -1;
			
		case TALK:
			randomTalk();
			return -2;
	}
	
	return -1;
}