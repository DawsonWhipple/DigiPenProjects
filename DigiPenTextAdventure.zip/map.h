/*****************
Filename: 	map.h
Author: 	Dawson Whipple
Date: 		1/26/18
Brief:		This code stores where the player currently is on the map and determines how to properly move bewteen locations
*****************/

#include "Parser.h"
#include <stdlib.h>
#include <time.h>

#define ROOMNUM 18

#define RANDTALKNUM 8

const char *ROOM_KEYS[ROOMNUM];

/* This is the list of all possible rooms the player can go into */
enum ROOMS {DETECTIVEONE, WINDOW, DETECTIVETWO, TOWNSQUARE, GASSTATION, BOTTOMLESS, GROCERY, BEHINDGROCERY, OUTSKIRTS, WOODS, DEEPWOODS, POST, BASEMENT, LOCKED, DEATHROOM, WINROOM, HIDEOUT, LAKE};

int detectiveOne(InputData data);

int detectivetwo(InputData data);

int townsquare(InputData data);

int gasstation(InputData data);

int grocery(InputData data);

int behindGrocery(InputData data);

int outskirts(InputData data);

int deepwoods(InputData data);

int post(InputData data);

int basement(InputData data);

int locked(InputData data);

int winroom(InputData data);

int lake(InputData data);