/*
Name: Includes.h
By: David Cohen
Date: 1/23/18
Brief: Contains basic definitions and includes
*/
#ifndef INCLUDED
#define INCLUDED
/* Boolean definitions */
#define bool char
#define FALSE 0
#define TRUE 1

/* Includes */
/* fgets, puts, printf */

#include <stdio.h>
#include <stdlib.h>
#endif