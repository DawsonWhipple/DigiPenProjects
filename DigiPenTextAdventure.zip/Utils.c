/*
Name: Utils.c
By: David Cohen
Date: 1/25/18
Brief: Contains basic utility functions
*/

/* Includes */
#include "Includes.h"
#include "Utils.h"
#include <string.h>
#include <ctype.h>

/* math.h's pow, but using integers */
int intPow(int num, int exponent)
{
	int i, out = 1;
	
	for (i = 0; i < exponent; i++)
	{
		out *= num;
	}
	
	return out;
}

/* Generic array copying function */
/* Uses unsigned char* as the type so it copies individual bytes (don't need different functions for different types) */
void copyArray(unsigned char *source, unsigned char *dest, int size)
{
    int i;
    
    for (i = 0; i < size; i++)
    {
        dest[i] = source[i];
    }
}

/* Remove illegal characters from the string and make the string lowercase */
void sanitize(char *str)
{
	int i, len = (int) strlen(str);
	
    /* go through each character in string */
	for (i = 0; i < len; i++)
	{
        /* break if we hit the end of the string somehow */
		if (str[i] == 0) break;
        /* convert character to lower-case */
		str[i] = tolower(str[i]);
        /* remove character if it is not a letter or a space */
		if ((str[i] < 97 || str[i] > 122) && str[i] != ' ')
		{
			shiftStr(str, len--, i--, 1);
		}
	}
    
    /* remove excess spaces */
    trim(str);
}

/* Remove spaces at the start and end of the string and extra stacked spaces */
void trim(char *str)
{
	int i, len = (int) strlen(str);
	
    /* go from the start of the string to the end of the string and remove any spaces, break when you encounter the first non-space character */
	/* (removes extra spaces at the beginning) */
    for (i = 0; i < len; i++)
	{
		if (str[i] != ' ') break;
        shiftStr(str, len, i--, 1);
        len = (int) strlen(str);
	}
    
    /* go from the end of the string to the start of the string and remove any spaces, break when you encounter the first non-space character */
    /* (removes extra spaces at the end) */
    for (i = len - 1; i >= 0; i--)
	{
		if (str[i] != ' ') break;
        str[i] = 0;
	}
    
    /* go from the start of the string to the end of the string and remove any spaces where the previous character was a space */
    /* (removes extra spaces in a row in the middle of the string) */
    for (i = 1; i < len; i++)
	{
        if (str[i] == ' ' && str[i - 1] == ' ')
        {
            shiftStr(str, len, i--, 1);
            len = (int) strlen(str);
        }
	}
}

/* Shift a string (offset) characters forward from (index) and on, used for removing characters in the middle of a string */
void shiftStr(char *str, int len, int index, int offset)
{
	int i;
	
	if (offset < 1) return;
	
    /* Starting at (index), go to the end of the string, replacing every character with the character (offset) ahead */
	for (i = index; i < len; i++)
	{
		int pos = i + offset;
        /* Clamp the character index we're copying from to the length of the string (don't go outside array bounds) */
		if (pos > len) pos = len;
		str[i] = str[pos];
	}
    
    /* Add a NUL terminator at the end just in case */
    str[len - 1] = 0;
}

/* Substring function, copy characters from (start [inclusive]) to (end [exclusive]) and place them in (out) */
void subStr(char *in, char *out, int start, int end)
{
	int i, j = 0;
	
    /* Clamp end to a maximum of 255 */
	if (end > 255) end = 255;
	
	for (i = start; i < end; i++)
	{
		out[j++] = in[i];
	}
    
    /* Add a NUL terminator at the end just in case */
    out[j] = 0;
}

/* Splits a string into an array, where each item is what was in between a space */
void splitSpaces(char *in, char out[16][256], int *found)
{
	int i, j, start, len = strlen(in);
	
    /* Reset variables */
	j = 0;
	start = 0;
	
	*found = 0;
	
    /* Loop through whole string (including NUL terminator) */
	for (i = 0; i <= len; i++)
	{
        /* If a space, newline, or NUL terminator is found */
		if (in[i] == ' ' || in[i] == '\n' || in[i] == 0)
		{
            /* Add a NUL terminator to the end of the current word */
			out[j++][i - start] = 0;
            /* Increment the number of found words */
			++(*found);
            /* Update the start of the next word */
			start = i + 1;
            /* Skip to the next loop */
			continue;
		}
        /* Write the current character to the appropriate spot in the current word */
		out[j][i - start] = in[i];
	}
}

/* Finds the next word in the phrase list and leaves (*i) at the word index immediately after */
int findNextPhrase(char words[16][256], const char *phrases[], int phraseCount, int found, int *i)
{
	int j;
	
    /* Loop until you either find a valid phrase or hit the end of the word list */
	while (*i < found)
	{
        /* Loop through the phrase list */
		for (j = 0; j < phraseCount; j++)
		{
            /* Check if the current word matches one of the phrases */
			if (strcmp(words[*i], phrases[j]) == 0)
			{
                /* If so, place *i one index after the current word (for the next time the function is ran) */
				(*i)++;
                /* Return the current phrase's id */
				return j;
			}
		}
        /* This word doesn't match any phrases, go to the next word */
		(*i)++;
	}
    
	/* No more phrases in the word list */
	return -1;
}

/* Checks if a word is in the words array (used for recognizing non-command, non-item, non-NPC keywords) */
bool isWordInArray(char words[16][256], int wordCount, char *word)
{
	int i;
	
	/* Loop through the word list */
	for (i = 0; i < wordCount; i++)
	{
		/* If the specified word is found, return true */
		if (strcmp(words[i], word) == 0) return TRUE;
	}
	
	/* The word wasn't found, return false */
	return FALSE;
}