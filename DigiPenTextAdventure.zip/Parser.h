/*
Name: Parser.h
By: David Cohen
Date: 1/26/18
Brief: Contains the main parser functionality
*/

/* Includes */
#include "Includes.h"

#ifndef _PARSER_H
#define _PARSER_H

/* Inventory is an integer used as a bitfield (int = 4 bytes = 32 bits = 32 slots) */
unsigned int inventory;

#define ITEM_COUNT 5
const char *ITEM_KEYS[ITEM_COUNT];
enum ITEMS {KEY, JERKY, CHEESE, RACCOON, FISH};

#define COMMAND_COUNT 10
const char *COMMAND_KEYS[COMMAND_COUNT];
enum COMMANDS {QUIT, HELP, NORTH, EAST, SOUTH, WEST, LOOK, TAKE, USE, TALK};

#define NPC_COUNT 3
const char *NPC_KEYS[NPC_COUNT];
enum NPCS {DAN, DAVID, DAWSON};

/* Struct for use as the output of getInput */
typedef struct {
    char words[16][256];
    int wordsCount;
    int commands[16];
    int commandsCount;
    int items[16];
    int itemsCount;
	int npcs[16];
	int npcsCount;
} InputData;

/* Checks the inventory bitfield for if the user has the item at (index) */
bool hasItem(int index);

/* Sets whether the user has the item at (index) in the inventory bitfield */
void setItem(int index, bool enabled);

/* Gets input from the user and returns all found info in the form of a neat struct */
InputData getInput(char *input, int bufSize);

#endif