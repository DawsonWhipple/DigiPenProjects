/*
Name: Utils.h
By: David Cohen
Date: 1/25/18
Brief: Contains basic utility functions
*/

/* Includes */
#include "Includes.h"

/* math.h's pow, but using integers */
int intPow(int num, int exponent);

/* Generic array copying function */
/* Uses unsigned char* as the type so it copies individual bytes (don't need different functions for different types) */
void copyArray(unsigned char *source, unsigned char *dest, int size);

/* Remove illegal characters from the string and make the string lowercase */
void sanitize(char *str);

/* Remove spaces at the start and end of the string and extra stacked spaces */
void trim(char *str);

/* Shift a string (offset) characters forward from (index) and on, used for removing characters in the middle of a string */
void shiftStr(char *str, int len, int index, int offset);

/* Substring function, cut out characters from (start [inclusive]) to (end [exclusive]) and place them in (out) */
void subStr(char *in, char *out, int start, int end);

/* Splits a string into an array, where each item is what was in between a space */
void splitSpaces(char *in, char out[16][256], int *found);

/* Finds the next word in the phrase list and leaves (*i) at the word index immediately after */
int findNextPhrase(char words[16][256], const char *phrases[], int phraseCount, int found, int *i);

/* Checks if a word is in the words array (used for recognizing non-command, non-item, non-NPC keywords) */
bool isWordInArray(char words[16][256], int wordCount, char *word);