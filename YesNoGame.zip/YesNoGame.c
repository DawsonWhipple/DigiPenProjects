/****************************
Filename: YesNoGame.c
Name: Dawson Whipple
Date Last Edited: 9/21/2017
Brief Description: Starting point for a yes no game
gcc -Wall -Wextra -O -ansi -pedantic -o yesnogame YesNoGame.c
****************************/
/*printf, scanf*/
#include <stdio.h>
/*rand, srand*/
#include <stdlib.h>
/*time*/
#include <time.h>
int main(void)
{
	/*valid inputs will be y, n, and q to quit*/
	char input;
	/*-1 descibes the starter event*/
	int eventID = -1;
	/*change this if you want to add more events*/
	int maxEventID = 5;
	/*set other game variables here, this could include a currents, special event triggers, how far down a specific event chain they are, ect.*/
	int money = 100;
	/*The amount of money the player has*/
	int happiness = 10;
	/*the opinion of the customers on the restaurant*/
	int onGoingEvent = 0;
	/*Gets updated when the on going event occurs*/
	int year = 1985;
	/*The current year: this will change every seventh event*/
	int day = 1;
	/*Ticks up after every event. When this reaches 7 the week resets and the next year ticks over.*/
	int choice = 0;
	/*Makes a 50/50% random choice*/
	
	
/*I have pushed all of my comments to the far left of the code to more easily differentiate it*/
	
	
	/*set random seed*/
	srand(time(NULL));
	/*introduction to game goes here, explain the rules to user */
	printf("Welcome, It is the year 1985. You are the proud owner of a newly opened record shop. You will need to make decisions in the form of yes or no questions that will further your progress and grow your brand. Remember! the decisions you make will have consequences.  Money: represents the amount of money you currently have. Happiness: is your customers opinion on your store. Be sure not to run out of money or it's game over. (PS. one week = one year) Good Luck!\n");
	
	/*There is no winning in this game. The story is that you're a record shop that is going to run out of business so as the years go on you start to lose money and happiness.*/
	/*The Goal of the game is to get as far as possible before running out of money*/
	
/*Waits for the player to activate the game*/
		while(input != 'b')
		{
			printf("\nPress b to begin:\n");
			/*scanf goes here*/
			scanf(" %c", &input);
			while(getchar()!= '\n');
		}
/*Start a do while loop that the game itself is encased in and keep running until the player inputs 'q'*/
	do
	{
		printf("Day %i\n",day);
		printf("Year %i\n",year);
		/*setting input to 'a' resets the input*/
		input = 'a';
		/*switch on the event, in each have something describing what the options are (y/n)*/
		switch(eventID){
			case -1:
				printf("Welcome, are you ready to make important choices about your business?\n");
				break;
			case 0:
				printf("You've just sold out of the latest hot album. Do you want to buy more?\n");
				break;
			case 1:
				printf("A customer has requested a refund. Should we give it to him?\n");
				break;
			case 2:
				printf("Sales are booming! should we bump up our prices to try and capitalize on this opportunity?\n");
				break;
			case 3:
				printf("A mysterious man says he he represents a very large company that can help you grow. Should you trust him?\n");
				break;
			case 4:
				printf("There are some hot new albums coming out that we don't have for sale. Should we start stocking them?\n");
				break;	
			case 5:
			if(onGoingEvent == 0)
			{
				printf("We can spend some extra money on advertising if you'd like? it'll get us more customers in the long run.\n");
			}
			else if(onGoingEvent == 1)
			{
				printf("People are starting to talk about our store thanks to the advertisments we invested in! Should we continue using them?\n");
			}
			else if(onGoingEvent == 2)
			{
				printf("Our sales have started to spike! I think it's from those advertising campaigns we've invested in. Isn't that amazing!\n");
			}
			else if(onGoingEvent == 3)
			{
				printf("Our ad campaign has finally run out. Would you like to see our total earnings?\n");
			}
				break;	
		}
		
		
		/*accept a character as input q quits everyting else should be n or y if none keep checking*/
		while(input != 'n' && input != 'y'&& input != 'q')
		{
			printf("\nEnter 'y' for yes or 'n' for no ('q' to quit):\n");
			/*scanf goes here*/
			scanf(" %c", &input);
			while(getchar()!= '\n');
		}
		/*switch on the event change outcome based on input*/
		switch(eventID){
			case -1:
/*This is for the first round of the game*/
				if(input == 'y')
				{
					printf("With any luck we will prosper!\n");
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n')
				{
					printf("This isn't looking good...\n");
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				break;
			case 0:
				if(input == 'y')
				{
					printf("We'll order some right away.\n");
					printf("Money -20\n");
					printf("Happiness +1\n\n");
					money -= 20;
					happiness += 1;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n')
				{
					printf("Our customers aren't going to like that very much.\n");
					printf("Happiness -1\n\n");
					happiness -= 1;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				break;
			case 1:
				if(input == 'y')
				{
					printf("This'll make us look good.\n");
					printf("Money -10\n\n");
					money -= 10;
					happiness += 1;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n')
				{
					printf("Very Well...\n");
					printf("Happiness -1\n\n");
					happiness -= 1;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				break;
			case 2:
				if(input == 'y')
				{
					printf("This will probably be a good idea in the long run. right?\n");
					printf("Money +30\n");
					printf("Happiness -3\n\n");
					money += 30;
					happiness -=3;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n')
				{
					printf("Good choice, our customers probably wouldn't have responded well\n");
					printf("Money +10\n");
					printf("Happiness +1\n\n");
					money += 10;
					happiness += 1;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				break;
			case 3:
/*The outcome is decided based on a 50/50% chance of being either beneficial or detrimental to the player*/
				if(input == 'y')
				{
					srand(time(NULL));
					choice = rand()% 2;
/*If the random number mod 2 equals 0 then the player loses the game in this instance*/
					if(choice == 0)
					{
						printf("They took your business and gave you nothing in return.\n\n");
						money = 0;
						happiness = 0;
						printf("You've Been Zuckerberged.\n\n");
					    printf("Money: %i\n",money);
					    printf("Happiness: %i\n\n",happiness);
					
					    while(input != 'q')
					    {
						printf("GAME OVER\n\n");
					 	printf("Press q to quit\n");
						/*scanf goes here*/
						scanf(" %c", &input);
					    }
					}
					else if(choice == 1)
					{
						printf("Our risks have been rewarded!\n");
						printf("Money +100\n\n");
						money += 100;
						printf("Money: %i\n",money);
					    printf("Happiness: %i\n",happiness);
					}
				}
				else if(input == 'n')
				{
					printf("Wise choice.\n");
					printf("Happiness +1\n\n");
					happiness += 1;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				break;
			case 4:
/*The outcome is decided based on a 50/50% chance of being either beneficial or detrimental to the player*/
				if(input == 'y')
				{
					srand(time(NULL));
					choice = rand()% 2;
					if(choice == 0)
					{
						printf("The new records will attract lots of customers!\n");
						printf("Money +20\n");
						printf("Happiness +2\n\n");
						money += 20;
						happiness += 2;
					    printf("Money: %i\n",money);
					    printf("Happiness: %i\n",happiness);
					
					    
					}
					else if(choice == 1)
					{
						printf("It seems that all of these albums just went out of style as we got them in stock. This was a bust.\n");
						printf("Money -50\n\n");
						money -= 50;
						printf("Money: %i\n",money);
					    printf("Happiness: %i\n",happiness);
					}
				}
				else if(input == 'n')
				{
					srand(time(NULL));
					choice = rand()% 2;
					if(choice == 0)
					{
						printf("I guess we'll just have to do without them then.\n");
						printf("Money -10\n");
						printf("Happiness -2\n\n");
						money -= 10;
						happiness -= 2;
					    printf("Money: %i\n",money);
					    printf("Happiness: %i\n",happiness);
					
					    
					}
					else if(choice == 1)
					{
						printf("Smart choice, we'll save money by doing this.\n");
						printf("Money +10\n\n");
						money += 10;
						printf("Money: %i\n",money);
					    printf("Happiness: %i\n",happiness);
					}
				}
				break;
			case 5:
/*After every round that this scenario occurs the variable "onGoingEvent' is increased by one indicating that the next step in the ongoing scenario should be triggered*/
				if(input == 'y' && onGoingEvent == 0)
				{
					printf("We'll get on it right away.\n");
					printf("Money -40\n\n");
					money -= 40;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n' && onGoingEvent == 0)
				{
					printf("If you say so.\n");
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				if(input == 'y' && onGoingEvent == 1)
				{
					printf("Yes sir!\n");
					printf("Money -40\n");
					printf("Happiness +3\n\n");
					money -= 40;
					happiness += 3;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n' && onGoingEvent == 1)
				{
					printf("oh... Well we already bought another months worth of advertising time before we asked you.\n");
					printf("Money -40\n");
					printf("Happiness +3\n\n");
					money -= 40;
					happiness += 3;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				if(input == 'y' && onGoingEvent == 2)
				{
					printf("I know!\n");
					printf("Money +60\n");
					printf("Happiness +3\n\n");
					money += 60;
					happiness += 3;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n' && onGoingEvent == 2)
				{
					printf("oh... ok.\n");
					printf("Money +60\n");
					printf("Happiness +3\n\n");
					money += 60;
					happiness += 3;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				if(input == 'y' && onGoingEvent == 3)
				{
					printf("Here you go!\n");
					printf("Money +100\n");
					printf("Happiness +5\n\n");
					onGoingEvent = -1;
					money += 100;
					happiness += 5;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				else if(input == 'n' && onGoingEvent == 3)
				{
					printf("Well we're going to tell you anyways.\n");
				    printf("Money +100\n");
					printf("Happiness +5\n\n");
					onGoingEvent = -1;
					money += 100;
					happiness += 5;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
				onGoingEvent += 1;
				break;	
		}
/*At the end of every round the day is increased by one*/
		day += 1;
/*The day keeps increasing until it reaches day 7 when the day variable is then reset and the year variable increases by one*/
		if(day == 7 && money > 0)
		{
			day = 1;
			year += 1;
			printf("\nThe year is now %i\n",year);
			
		}	
/*If the happiness variable ever drops to or below 0 the player will lose money after every turn until the happiness variable is greater than 0*/
		if(happiness <= 0 && money > 0)
				{
					printf("\nWe seem to be doing very poorly. We are losing money.\n\n");
					printf("Money -10\n\n");
					money -= 10;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
/*As the years go on the player begins to lose both money and happiness in order to give the game an end goal of getting as far as possible without actually making an end goal to the game*/				
		if(year == 1990 && day == 1)
				{
					printf("It seems like people are starting use different mediums to listen to their music. This isn't looking good for us\n");
					printf("(You will start to lose money and happiness reguraly now.)\n\n");
					
				}
		if(year >= 1990 && year <= 1992)		
				{	
					printf("Money -10\n");
					printf("Happiness -1\n\n");
					money -= 10;
					happiness -= 1;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
/*This message will appear only on the first day of the year 1993 to alert the player that they will be losing mioney and happiness*/
		if(year == 1993 && day == 7)
		{
			printf("It looks like records are starting to go out of style. We won't be in business very much longer at this rate\n");
			printf("(You will now lose money and happiness at an accelrated rate.)\n\n");
		}	
		if(year >= 1993)
				{
					printf("Money -30\n");
					printf("Happiness -2\n\n");
					money -= 30;
					happiness -= 2;
					printf("Money: %i\n",money);
					printf("Happiness: %i\n",happiness);
				}
/*If the players money drops to 0 then the game is over*/	
		if(money <= 0 && input != 'q')
				{
					printf("You've run out of money and have to file for bankruptcy.\n\n");
					while(input != 'q')
					{
						printf("GAME OVER\n\n");
						printf("Press q to quit\n");
						/*scanf goes here*/
						scanf(" %c", &input);
					}
				}
/*Waits for the player to press ENTER before proceeding with the next round of the game*/
		printf("Press ENTER to Continue\n");
		while(getchar()!= '\n');		
		
	
		/*reset event id with rand*/
		eventID = rand() % (maxEventID + 1);
		
		
	}while(input != 'q');
	
	
	return 0;
}

