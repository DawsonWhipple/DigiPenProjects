/****************
vigenereCipher.c
By:		Dawson Whipple
Date:	1/18/18
Brief:	Creates a vigenere cipher
gcc -O -Wall -Wextra -ansi -pedantic -o vcipher vigenereCipher.c main.c
****************/
#include <string.h>
#include <stdio.h>
#include "vigenereCipher.h"

void vigenere(unsigned char *string, unsigned char *key, enum CODE_METHOD method, int passes)
{
	unsigned int i, j;
	int n;		
	if(method == ENCODE)
	{
		/* repeats encoding process for the amount of passes input by the player */
		for(n =0; n < passes; n++)
		{
			for(i = 0, j= 0; i < strlen((char*)string); i++)
			{
				/* Check if key is a capital letter */
				if((int)key[j] >= 65 && (int)key[j] <= 90)
				{
					key[j] += 32;
				}
				/* if j is greater than the length of key, reset j */
				if(j >= strlen((char*)key))
				{
					j = 0;
				}	
				/* check if string is a capital letter */
				if((int)string[i] >= 65 && (int)string[i] <= 90)
				{
					string[i] += 32;
				}
				/* only changes the value of string and inreases j by one if the value for string[i] is a lower case letter. this is done to preserve spaces */
				if((int)string[i] >= 97 && (int)string[i] <= 123)
				{
					string[i] = string[i] + (key[j] - 97);
					j++;
				}
				/* if the new value of string[i] is above the ASCII values for lower case letters, subtract 26 to get it back in the proper ASCII values */
				if((int)string[i] >= 123)
				{
					string[i] -= 26;
				}
			}
		}
	}
	if(method == DECODE)
	{
		/* repeats encoding process for the amount of passes input by the player */
		for(n =0; n < passes; n++)
		{
			for(i = 0, j= 0; i < strlen((char*)string); i++)
			{
				/* Check if key is a capital letter */
				if((int)key[j] >= 65 && (int)key[j] <= 90)
				{
					key[j] += 32;
				}
				/* if j is greater than the length of key, reset j */
				if(j >= strlen((char*)key))
				{
					j = 0;
				}	
				/* only changes the value of string and inreases j by one if the value for string[i] is a lower case letter. this is done to preserve spaces */
				if((int)string[i] >= 97 && (int)string[i] <= 123)
				{
					/* subtracts (key[j] + 97) from string instead of adding to reverse the encoding process */
					string[i] = string[i] - key[j] + 97;
					j++;
					/* if the new value of string[i] is below the ASCII values for lower case letters, add 26 to get it back in the proper ASCII values */
					if((int)string[i] < 97)
					{
						string[i] += 26;
					}
				}
			}
		}
	}
	return;
}