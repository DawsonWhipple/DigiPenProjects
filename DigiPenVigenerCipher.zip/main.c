/****************
main.c
By:		Dawson Whipple
Date: 	1/18/18
Brief: The test file to use with vigenereCipher.c.  You will need to set it up to take input from the console for both the string to encrypt and the key to encrypt with, please use the provided arrays!  After encrypting also test the decrypting! 
gcc -O -Wall -Wextra -ansi -pedantic -o vcipher vigenereCipher.c main.c
****************/
#include <stdio.h>
#include <string.h>
#include "vigenereCipher.h"

int main(void)
{
	unsigned char string[256];
	unsigned char key[32];
	int passes;
	
	/*ask for the string to encrypt and store it in string*/
	puts("Enter the string you would like to encode");
	fgets((char*)string, 256, stdin);
	string[strlen((char*)string) - 1] = 0;
	
	/*ask for the key to encrypt with and store it in key*/
	puts("Enter the encryption code");
	fgets((char*)key, 32, stdin);
	key[strlen((char*)key) - 1] = 0;
	
	/*ask for how many passes to encrypt with*/
	puts("Enter the number of passes you'd like to encrypt");
	scanf("%i", &passes);
	
	/*encrypt string with the key, make sure set to encode!*/
	vigenere(string, key, ENCODE, passes);
	/*print out the encoded string*/
	puts((char*)string);
	/*now reverse it back to normal by setting it to decode and print it out again*/
	vigenere(string, key, DECODE, passes);
	/*print out the decoded string*/
	puts((char*)string);
	return 0;
}