/**************************
Filename:	calendar.c
Author: 	Dawson Whipple
Date: 		1/2/18
Brief: 		This program calculates and prints out a calender for a given month in a given year
gcc -Wall -Wextra -pedantic -ansi -O -o calendar calendar.c main.c
**************************/

#include <stdio.h>

#define TRUE  1
#define FALSE 0
/* Determines if the given year is a leap year */
int is_leapyear(int year)
{
	if(year % 4 == 0)
	{
		if(year % 400 == 0)
		{
			return 1;
		}
		else if(year % 100 == 0)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		return 0;
	}
}
/* Determines the day of the week for each specific dates */
int day_of_the_week(int day, int month, int year)
{
	int month_keys[] = {1, 4, 4, 0, 2, 5, 0, 3, 6, 1, 4, 6};
	int year_keys[] = {4, 2, 0, 6};
	int temp, temp2;

	temp = year % 100;
	temp /= 4;
	temp += day;
	temp += month_keys[month -1];
	if((month == 1 || month == 2) && is_leapyear(year))
	{
		--temp;
	}	
	/* Checks to make sure the given year does not excede 2099 */
	while(year > 2099)
	{
		year -= 400;
	}
	/* calculates what day of the week the given date is */
	temp2 = year/100;
	temp += year_keys[temp2 - 17];
	temp += year % 100;
	temp %= 7;
	if(temp == 0)
	{
		temp += 7;
	}
	return temp;
}

void print_calendar(int month, int year)
{
	int days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	char *months[] = {"January",   "February", "March",    "April", 
						"May",       "June",     "July",     "August",
						"September", "October",  "November", "December"};
	int leapyear = is_leapyear(year);
	int first_day = day_of_the_week(1, month, year);
	int i, j;
	int n = 1;
	
		/* Print calendar header */
	printf("%s, %i\n", months[month - 1], year);
	printf("Su Mo Tu We Th Fr Sa\n");
	printf("---------------------\n");
	/* Determines if the year is a leapyear. if so, adds one day to february */
	if(month == 2 && leapyear == 1)
	{
		days_in_month[1] += 1;
	}
	/* prints blank space at begining of calender if needed */
	for(i = 1; i < first_day; i++)
	{
		printf("   ");
		++n;
	}
	/* prints each date under the correct day of the week */
	for(j = 1; j <= days_in_month[month-1]; j++)
	{
		printf("%2i ",j);
		if(n % 7 == 0)
		{
			
			printf("\n");
		}
		++n;
	}
	printf("\n");
}

